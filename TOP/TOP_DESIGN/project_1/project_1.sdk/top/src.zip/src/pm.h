/*
 * pm.h
 *
 *  Created on: 2023��6��4��
 *      Author: Chen
 */

#ifndef PM_H_
#define PM_H_
#include "stdio.h"
#include "oled.h"
#include "tts.h"
#include "xparameters.h"

void ShowPM();

#endif /* PM_H_ */
