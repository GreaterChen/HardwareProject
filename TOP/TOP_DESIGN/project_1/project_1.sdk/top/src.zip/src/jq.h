/*
 * jq.h
 *
 *  Created on: 2023��6��6��
 *      Author: Chen
 */

#ifndef JQ_H_
#define JQ_H_
#include "xparameters.h"
#include "xil_io.h"
#include "oled.h"
#include "tts.h"

void ShowJQ();

#endif /* JQ_H_ */
